function stPendel = ladePendel()
    stPendel.g = 9.81;
    stPendel.m1 = 0.3;
    stPendel.m2 = 0.3;
    stPendel.l1 = 0.2;
    stPendel.l2 = 0.2;
    stPendel.Rp1 = 0;
    stPendel.Rp2 = 0;
end 