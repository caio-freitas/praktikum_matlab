function L = berechneBeobachter(A,C,obspoles)
    
end